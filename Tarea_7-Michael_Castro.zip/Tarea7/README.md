usuarios
![image](https://github.com/user-attachments/assets/7b83c1e5-0dfe-4365-9902-0f232ee9da98)
![image](https://github.com/user-attachments/assets/6fe55a6b-7982-4257-ab87-1c3dc9967d7b)
![image](https://github.com/user-attachments/assets/6dac79ca-d183-44ad-91a1-c1952c273b5d)

reportes
![image](https://github.com/user-attachments/assets/6ac9b9b0-b5db-42b0-90ea-d7836a71b721)
![image](https://github.com/user-attachments/assets/0b9c7757-cc51-4995-a0bb-74e87d50754d)

Roles
![image](https://github.com/user-attachments/assets/2003090e-cd2d-4322-b75c-d11a18457b22)
![image](https://github.com/user-attachments/assets/e06912fd-b1f2-41db-8c66-7b23dbb09ecc)
